import unittest
from pathlib import Path
import numpy as np
import pandas as pd
import sentiment as s


def fixture(n=420):
    rng = np.random.default_rng(271828)
    dates = pd.bdate_range('2017-01-02', periods=n)
    close = 100*np.exp(np.cumsum(rng.normal(.0002,.012,n)))
    ix = pd.DataFrame({'date':dates,'open':close,'close':close,'high':close*1.01,'low':close*.99})
    up = rng.integers(150,850,n)
    ma = rng.integers(100,950,n)
    m = pd.DataFrame({'date':dates, 'n_eligible':1020,'n_expected_traded':1000,'n_traded':1000,
                      'n_up':up,'n_down':1000-up,'n_flat':0,'n_above_ma20':ma,'n_ma20':1000,
                      'n_drop5':np.minimum(1000-up,rng.integers(0,120,n)), 'amount_yuan':1e12})
    f = pd.DataFrame({'date':dates,'available_date':dates+pd.offsets.BDay(1),
                      'buy_yuan':rng.uniform(5e10,10e10,n),'repay_yuan':rng.uniform(5e10,10e10,n)})
    meta = {k:True for k in ['point_in_time','includes_delisted','st_history_verified',
                             'adjustment_verified','calendar_verified']}
    meta.update(universe='CN_SH_SZ_A_NONST_60',source='SYNTHETIC TEST DATA ONLY')
    meta.update(finance_scope='CN_SH_SZ_A_STOCK_ONLY',finance_availability_verified=True)
    return ix,m,f,meta


class Tests(unittest.TestCase):
    def test_half_rank_ties(self):
        a=s.rank_past(pd.Series([1.,2.,2.,3.,2.]),window=4,minimum=4)
        self.assertEqual(a.iloc[-1],50)
        self.assertEqual(s.rank_past(pd.Series([1.,1.,1.,1.,1.]),4,4).iloc[-1],50)
        self.assertEqual(s.rank_past(pd.Series([1.,2.,2.,3.,0.]),4,4).iloc[-1],0)
        self.assertEqual(s.rank_past(pd.Series([1.,2.,2.,3.,4.]),4,4).iloc[-1],100)

    def test_history_coverage(self):
        a=pd.Series(np.arange(300,dtype=float)); a.iloc[100:140]=np.nan
        self.assertTrue(pd.isna(s.rank_past(a).iloc[-1]))
        self.assertTrue(s.rank_past(pd.Series(np.arange(252,dtype=float))).isna().all())

    def test_no_lookahead_full_model(self):
        ix,m,f,meta=fixture()
        a=s.calculate(ix,m,f,meta)
        b=s.calculate(ix.iloc[:350],m.iloc[:350],f.iloc[:350],meta)
        for col in ['S','P']+list(s.WEIGHTS)+['q_'+k for k in s.WEIGHTS]:
            pd.testing.assert_series_equal(a.loc[b.index,col],b[col])
        self.assertTrue(np.isfinite(a.S.iloc[-1]))
        self.assertTrue(a.S.dropna().between(0,100).all())
        self.assertAlmostEqual(a.factor_coverage.iloc[-1],1)

    def test_missing_factor_not_reweighted(self):
        ix,m,f,meta=fixture()
        a=s.calculate(ix)
        self.assertTrue(a.S.isna().all())
        self.assertTrue(pd.notna(a.P.iloc[-1]))
        self.assertAlmostEqual(a.factor_coverage.iloc[-1],.4)
        m.loc[len(m)-1,'n_drop5']=np.nan
        a=s.calculate(ix,m,f,meta)
        self.assertTrue(pd.isna(a.S.iloc[-1]))

    def test_finance_publication_date(self):
        ix,m,f,meta=fixture()
        a=s.calculate(ix,m,f,meta)
        # Last-day flows cannot change today's information set.
        f.loc[len(f)-1,'buy_yuan']=1e15
        b=s.calculate(ix,m,f,meta)
        self.assertEqual(a.leverage.iloc[-1],b.leverage.iloc[-1])
        self.assertEqual(a.finance_trade_date.iloc[-1],a.index[-2])
        # A four-session publication outage must invalidate current leverage.
        f.loc[len(f)-5:,'available_date']=pd.Timestamp('2099-01-01')
        c=s.calculate(ix,m,f,meta)
        self.assertTrue(pd.isna(c.leverage.iloc[-1]))

    def test_bad_partition_with_other_missing_field(self):
        ix,m,f,meta=fixture()
        m.loc[400,'n_ma20']=np.nan
        m.loc[400,'n_up']=1001
        with self.assertRaises(ValueError): s.calculate(ix,m,f,meta)

    def test_low_observation_coverage(self):
        ix,m,f,meta=fixture()
        m.loc[419,['n_traded','n_up','n_down','n_flat','n_ma20','n_above_ma20','n_drop5']]=[800,400,400,0,800,400,10]
        a=s.calculate(ix,m,f,meta)
        self.assertTrue(pd.isna(a.breadth.iloc[-1]))
        self.assertTrue(pd.isna(a.ma20.iloc[-1]))
        self.assertTrue(pd.isna(a.tail5.iloc[-1]))
        self.assertAlmostEqual(a.suspension_share.iloc[-1],1-1000/1020)

    def test_duplicate_and_invalid_ohlc(self):
        ix,*_=fixture()
        with self.assertRaises(ValueError): s.calculate(pd.concat([ix,ix.tail(1)]))
        ix.loc[20,'high']=ix.loc[20,'low']*.9
        with self.assertRaises(ValueError): s.calculate(ix)

    def test_week_base_and_midweek_alert(self):
        ix,*_=fixture(420)
        ix=ix.iloc[:400].copy()
        # Make final dates Monday-Friday, prepend enough valid history.
        dates=pd.bdate_range(end='2026-09-11',periods=len(ix));ix['date']=dates
        closes=[100,95,94,100,102,103]
        for row,value in zip(ix.index[-6:],closes):
            ix.loc[row,['open','close','high','low']]=[value,value,value*1.005,value*.995]
        a=s.calculate(ix)
        report=s.weekly_report(a,pd.Timestamp('2026-09-11'))
        self.assertIn('周涨跌 3.00%',report)
        self.assertIn('红色预警',report)
        self.assertIn('2026-09-07',report)
        self.assertIn('周内收盘最大回撤 -6.00%',report)

    def test_big_upward_move_alerts(self):
        ix,*_=fixture(); a=s.calculate(ix)
        a.loc[a.index[-1],'r1']=.06
        alerts=s.daily_alerts(a)
        self.assertGreaterEqual(alerts.level.iloc[-1],2)
        self.assertIn('正向波动',alerts.reasons.iloc[-1])

    def test_stale_input_and_missing_day(self):
        raw=pd.read_csv(Path(__file__).parent/'index.csv')
        raw=raw.loc[pd.to_datetime(raw.date)<='2026-09-11']
        a=s.calculate(raw)
        with self.assertRaises(ValueError): s.weekly_report(a,pd.Timestamp('2026-09-14'))
        with self.assertRaises(ValueError): s.calculate(raw.drop(raw.index[-3]))

    def test_current_week_arithmetic(self):
        raw=pd.read_csv(Path(__file__).parent/'index.csv')
        raw=raw.loc[pd.to_datetime(raw.date)<='2026-09-11']
        a=s.calculate(raw)
        self.assertAlmostEqual(a.loc['2026-09-11','r5'],5769.02/5830.14-1)
        self.assertAlmostEqual(a.loc['2026-09-11','P'],21.16402116402116)


if __name__=='__main__': unittest.main(verbosity=2)
