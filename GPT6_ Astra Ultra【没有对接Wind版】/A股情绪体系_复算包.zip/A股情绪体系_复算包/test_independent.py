"""Independent checks; default module is the frozen first-draft snapshot.
Run: python work/test_independent.py [sentiment|independent_review_snapshot]
"""
import importlib
import sys
import unittest

import numpy as np
import pandas as pd

s = importlib.import_module(sys.argv.pop(1) if len(sys.argv) > 1 else 'independent_review_snapshot')


def inputs(n=900):
    dates = pd.bdate_range('2017-01-02', periods=n)
    close = 100 * np.exp(np.cumsum(.001 + .012*np.sin(np.arange(n)/7)))
    idx = pd.DataFrame({'date': dates, 'open': close, 'close': close,
                        'high': close*1.001, 'low': close*.999})
    market = pd.DataFrame({'date': dates, 'n_eligible': 100, 'n_expected_traded': 100, 'n_traded': 100,
        'n_up': 40, 'n_down': 40, 'n_flat': 20, 'n_above_ma20': 50,
        'n_ma20': 100, 'n_drop5': 5, 'amount_yuan': 100_000_000})
    meta = {k:True for k in ['point_in_time','includes_delisted',
        'st_history_verified','adjustment_verified','calendar_verified']}
    meta.update(universe='CN_SH_SZ_A_NONST_60', source='SYNTHETIC INDEPENDENT TEST')
    meta.update(finance_scope='CN_SH_SZ_A_STOCK_ONLY', finance_availability_verified=True)
    finance = pd.DataFrame({'date': dates[:-1], 'available_date': dates[1:],
        'buy_yuan': np.arange(n-1)+10_000_000, 'repay_yuan': 5_000_000})
    return idx, market, finance, meta


class IndependentTests(unittest.TestCase):
    def test_midrank(self):
        result = s.rank_past(pd.Series([1., 2., 2., 3., 2.]), 4, 4)
        self.assertEqual(result.iloc[-1], 50.)

    def test_price_no_lookahead(self):
        idx, _, _, _ = inputs()
        full = s.calculate(idx)
        truncated = s.calculate(idx.iloc[:700])
        cols = ['r1','momentum','downvol','q_momentum','q_downvol','P','S']
        pd.testing.assert_frame_equal(full.iloc[:700][cols], truncated[cols])

    def test_finance_no_lookahead(self):
        idx, market, finance, meta = inputs()
        full = s.calculate(idx, market, finance, meta)
        cut = s.calculate(idx.iloc[:700], market.iloc[:700], finance.iloc[:700], meta)
        pd.testing.assert_frame_equal(full.iloc[:700][['leverage','S']], cut[['leverage','S']])
        # None of the observed financing windows ends on or after its reporting date.
        valid = full.finance_trade_date.notna()
        self.assertTrue((full.loc[valid,'finance_trade_date'] < full.index[valid]).all())

    def test_missing_core_does_not_reweight(self):
        idx, _, _, _ = inputs()
        result = s.calculate(idx)
        self.assertTrue(result.S.isna().all())
        self.assertAlmostEqual(result.factor_coverage.iloc[-1], .4)
        self.assertTrue(np.isfinite(result.P.iloc[-1]))

    def test_partial_row_cannot_bypass_invalid_counts(self):
        idx, market, _, meta = inputs()
        market.loc[899, 'n_above_ma20'] = np.nan
        market.loc[899, 'n_up'] = 200
        # Missing unrelated MA data must not make invalid breadth admissible.
        with self.assertRaises(ValueError):
            s.calculate(idx, market, None, meta)

    def test_delayed_finance_not_backfilled(self):
        idx, market, finance, meta = inputs(40)
        finance.loc[30, 'available_date'] = pd.Timestamp('2099-01-01')
        result = s.calculate(idx, market, finance, meta)
        # One absent publication blocks every five-session window that needs it.
        self.assertTrue(result.leverage.iloc[32:36].isna().all())

    def test_large_upside_move_triggers_volatility_observation(self):
        idx, _, _, _ = inputs()
        result = s.calculate(idx)
        result.loc[result.index[-1], ['r1','r5','rank_downvol']] = [.04, .04, 50]
        alert = s.daily_alerts(result).iloc[-1]
        self.assertGreater(alert.level, 0)

    def test_midweek_alert_survives_recovery(self):
        idx, _, _, _ = inputs()
        result = s.calculate(idx)
        # Use a complete week with an explicit Wednesday shock and Friday recovery.
        end = result.index[result.index.weekday == 4][-1]
        result = result.loc[:end]
        wed = end-pd.Timedelta(days=2)
        result.loc[wed,'r1'] = -.06
        result.loc[end, ['r1','r5']] = [.02, .02]
        report = s.weekly_report(result, end)
        self.assertIn('红色预警', report)
        self.assertIn(str(wed.date())+'：全指单日跌幅达到5%', report)


if __name__ == '__main__':
    unittest.main(verbosity=2)
