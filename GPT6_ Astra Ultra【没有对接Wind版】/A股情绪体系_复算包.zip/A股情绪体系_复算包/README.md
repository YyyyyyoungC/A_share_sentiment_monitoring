# A股情绪体系复算包

最新完整周：2026-09-07—2026-09-11。Python建议3.11+，本次3.12.14。

```powershell
python -m pip install -r requirements.txt
python sentiment.py --index-csv index.csv --index-meta index_meta.json --as-of 2026-09-11 --diagnostic --out result
python test_sentiment.py
python test_independent.py sentiment
```

不加`--with-context`即可离线运行，不依赖网络接口；依赖库需已安装。

预期：全指5769.02，周收益约-1.0483%，P约21.1640，完整S=NA。
完整S缺少同口径全市场历史广度、个股尾部、融资及可得性输入。
`reference_results`是冻结结果。含完整市场复盘和引用的报告在公式说明书中。

`sources/eastmoney985.txt`保留原始响应，可能含09-14盘中行；根目录index.csv已删除截止日之后记录。
`sources/funding_raw.json`是9月14日抓取的沪深融资业务汇总，不是合格的正式finance.csv。
海外周收盘在A股周五收盘后才可得，仅用于事后外围复盘。

日历检查：最近1022个行情日期与沪深300/创业板数据一致；这不等于全历史独立交易所日历已验收。
审计文件SHA256SUMS.txt可检查文件完整性，不证明来源本身一定无误。
